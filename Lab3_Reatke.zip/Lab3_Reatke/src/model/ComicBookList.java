/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class ComicBookList {

    private List<ComicBook> comics = new ArrayList<>();
    public String filename = "D:\\PRO192\\Lab3_Reatke\\src\\model\\comiclist.txt";
    Scanner scanner = new Scanner(System.in);
    ComicBook comicbook = new ComicBook();

    public void readfile(String filename) {

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 5) {
                    try {
                        String title = parts[0].trim();
                        String author = parts[1].trim();
                        String releaseDate = parts[2].trim();
                        int volume = Integer.parseInt(parts[3].trim());
                        int pages = Integer.parseInt(parts[4].trim());
                        comics.add(new ComicBook(title, author, releaseDate, volume, pages));

                    } catch (Exception e) {
                        System.out.println("invalid format, try again");
                    }
                }
            }
        } catch (IOException ioe) {
            System.out.println(ioe.getMessage());
        }
    }

    public void addcomic(ComicBook comicbook) {
        comics.add(comicbook);
    }

    public void searchcomicbook(String search) {
        for (ComicBook comicbook : comics) {
            if (comicbook.getTitle().equalsIgnoreCase(search) || comicbook.getAuthor().equalsIgnoreCase(search)) {
                System.out.println(comicbook);
            }
        }
    }

    public void sortcomicbook() {
        comics.sort(Comparator.comparingInt(ComicBook::getPages));
        displayallcomic();
    }

    public void deletecomicbooks() {
        List<ComicBook> comiclist1 = new ArrayList<>();
        LocalDate currentdate = LocalDate.now();
        for (ComicBook comicbook : comics) {
            if (comicbook.getReleaseDate().isBefore(currentdate.minusYears(10))) {
                comiclist1.add(comicbook);
            }
        }
        comics.removeAll(comiclist1);
    }

    public void displayallcomic() {
        for (ComicBook comicbook : comics) {
            System.out.println(comicbook);
        }
    }

}

