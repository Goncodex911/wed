/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class ComicBook {

    private String title;
    private String author;
    private LocalDate releaseDate;
    private int volume;
    private int pages;

    public ComicBook() {
    }

    public ComicBook(String title, String author, String releaseDate, int volume, int pages) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        this.title = title;
        this.author = author;
        try {
            this.releaseDate = LocalDate.parse(releaseDate, formatter);
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format for: " + title);
        }
        this.volume = volume;
        this.pages = pages;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public LocalDate getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(LocalDate releaseDate) {
        this.releaseDate = releaseDate;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    @Override
    public String toString() {
        return title + " | " + author + " | " + releaseDate + " | " + volume + " | " + pages;
    }

}
