/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author THUAN
 */   import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
public class LoadFile {
    public static void main(String[] args) {
        String content = """
                       One Piece|Eiichiro Oda|22/07/1997|1|208
                       Naruto|Masashi Kishimoto|21091999|1|195
                       Attack on Titan|Hajime Isayama|09/09/2009|1|190
                       My Hero Academia|Kohei Horikoshi|07/07/2014|1|192
                       Demon Slayer|Koyoharu Gotouge|15/02/2016|1|182
                         """;

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("comiclist.txt"))) {
            writer.write(content);
            System.out.println("File created successfully!");
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file: " + e.getMessage());
        }
    }
}

    

