/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author THUAN
 */

import view.Menu;
import model.ComicBookList;

public class ComicBookManagement {

    public static void main(String[] args) {
        ComicBookList comiclist = new ComicBookList();
        comiclist.readfile(comiclist.filename);
        Menu menu = new Menu(comiclist);
        menu.run();
    }
}
