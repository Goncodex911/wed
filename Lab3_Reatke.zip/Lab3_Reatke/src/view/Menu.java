/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author THUAN
 */
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
import model.ComicBook;
import model.ComicBookList;

public class Menu extends ComicListView {

    Scanner sc = new Scanner(System.in);
    private ComicBookList comiclist;

    public Menu(ComicBookList comiclist) {
        super("Comic Book Management", new String[]{
            "1. Add a new comic book",
            "2. Display all comic books",
            "3. Display sorted comic books by the number of pages",
            "4. Search comic books",
            "5. Delete comic books",});
        this.comiclist = comiclist;
    }

    public void execute(int n) {
        switch (n) {
            case 1:
                addComic();
                break;
            case 2:
                comiclist.displayallcomic();
                break;
            case 3:
                comiclist.sortcomicbook();
                break;
            case 4:
                System.out.print("Enter title or author to search: ");
                String search = sc.nextLine();
                comiclist.searchcomicbook(search);
                break;
            case 5:
                comiclist.deletecomicbooks();
                break;
            default:
                System.out.println("Invalid selection, please try again.");
                break;
        }
    }

    public void addComic() {
        System.out.print("Enter title: ");
        String title = sc.nextLine();
        System.out.print("Enter author: ");
        String author = sc.nextLine();
        System.out.print("Enter release date (dd/MM/yyyy): ");
        String date = sc.nextLine();
        System.out.print("Enter volume: ");
        int volume = Integer.parseInt(sc.nextLine());
        System.out.print("Enter pages: ");
        int pages = Integer.parseInt(sc.nextLine());

        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate releaseDate = LocalDate.parse(date, formatter);
            ComicBook comic = new ComicBook(title, author, releaseDate.toString(), volume, pages);
            comiclist.addcomic(comic);

        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format. Comic book not added.");
        } catch (NumberFormatException e) {
            System.out.println("Invalid number format. Please enter valid numbers for volume and pages.");
        }
    }

    public void searchComic() {
        System.out.print("Enter title or author to search: ");
        String search = sc.nextLine();
        comiclist.searchcomicbook(search);
    }
}

